Client-side JS (Angular) for MEAN stack Gmail clone.
